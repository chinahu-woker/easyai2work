// 本文件由FirstUI授权予佛山市航电梦联网络科技有限公司（会员ID：  112 7，营业执照号：9  1 44    0 605M A55 6 H 1K     XH）专用，请尊重知识产权，勿私下传播，违者追究法律责任。
export function getTransferedObjectUUID(name, id) {
    return `${name.toLowerCase()}-${id}`;
}