// 本文件由FirstUI授权予佛山市航电梦联网络科技有限公司（会员ID：  1 127，营业执照号：914    4 06 0    5 M  A5 56 H 1K XH）专用，请尊重知识产权，勿私下传播，违者追究法律责任。
class FillStylePattern {
    constructor(img, pattern) {
        this._style = pattern;
        this._img = img;
    }
}

export default FillStylePattern;