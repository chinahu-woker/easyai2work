// 本文件由FirstUI授权予佛山市航电梦联网络科技有限公司（会员ID：  112 7，营业执照号： 9  1 4 406  0 5MA  5 5 6  H   1KXH）专用，请尊重知识产权，勿私下传播，违者追究法律责任。
export function getTransferedObjectUUID(name, id) {
    return `${name.toLowerCase()}-${id}`;
}