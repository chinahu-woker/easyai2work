<template>
	<!--本文件由FirstUI授权予佛山市航电梦联网络科技有限公司（会员ID：11   27，营业执照号：91 44     06 0 5   M A5 5    6H1KXH）专用，请尊重知识产权，勿私下传播，违者追究法律责任。-->
	<view>

	</view>
</template>

<script>
	export default {
		name:"fui-charts-line",
		data() {
			return {

			};
		}
	}
</script>

<style>

</style>