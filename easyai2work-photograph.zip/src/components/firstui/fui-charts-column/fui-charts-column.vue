<template>
	<!--本文件由FirstUI授权予佛山市航电梦联网络科技有限公司（会员ID：  11 27，营业执照号： 9  144 0 6  0 5M   A55  6 H1 K X H）专用，请尊重知识产权，勿私下传播，违者追究法律责任。-->
	<view>

	</view>
</template>

<script>
	export default {
		name:"fui-charts-column",
		data() {
			return {

			};
		}
	}
</script>

<style>

</style>