export * from './data/globalAppData.ts'
